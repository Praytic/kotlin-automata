**Build instructions:**  
To build project you should have Gradle 3.1+ and JVM 1.8.0_101+ and run command:  
`gradle build`  
To run project use command:  
`gradle run`  